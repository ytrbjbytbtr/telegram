// Global using directives

global using System;
global using Newtonsoft.Json;
global using Newtonsoft.Json.Serialization;
global using Telegram.Bot.Types;
