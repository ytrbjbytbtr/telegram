using System.Runtime.CompilerServices;

[assembly: InternalsVisibleTo("Telegram.Bot.Tests.Unit")]
[assembly: InternalsVisibleTo("Telegram.Bot.Tests.Integ")]
[assembly: CLSCompliant(false)]
