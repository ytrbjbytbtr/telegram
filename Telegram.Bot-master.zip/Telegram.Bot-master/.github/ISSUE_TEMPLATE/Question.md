---
name: Question
about: Got a question or need help
custom_fields: []

---

# I have a question or need help

Please **DO NOT** post it! We don't provide support in GitHub issues any more.

We would be happy if you join our group chat on Telegram [![@tgbots_dotnet](https://img.shields.io/badge/@tgbots__dotnet-Telegram-blue.svg)](https://t.me/tgbots_dotnet) and ask the community to help.

> If you open an issue asking for support, the issue would be closed without providing any answer.