---
name: Feature Request
about: Suggest an idea for this project
custom_fields: []

---

## I would like to request/propose a feature

That's great. Let us know what's on on your mind and please try to be specific.

You also can chat with us on Telegram [![@tgbots_dotnet](https://img.shields.io/badge/@tgbots__dotnet-Telegram-blue.svg)](https://t.me/tgbots_dotnet)
