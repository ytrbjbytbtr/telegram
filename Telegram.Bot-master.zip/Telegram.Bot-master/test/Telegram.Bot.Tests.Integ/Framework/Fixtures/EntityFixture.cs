﻿namespace Telegram.Bot.Tests.Integ.Framework.Fixtures;

public class EntityFixture<TEntity>
{
    public TEntity Entity { get; set; }
}